const MXGasolineContainer = () => {
  return (
    <div className="absolute top-[675px] left-[693px] w-[592px] h-[150px] text-left text-base text-colors-primary-white font-typography-button-large">
      <div className="absolute top-[0px] left-[0px] rounded-3xs bg-color-cards w-[592px] h-[150px]" />
      <div className="absolute top-[10.67%] left-[70.44%] text-sm">
        <span className="leading-[22px]">Starts at</span>
        <b className="text-lg leading-[26px]"> ₹9,00,000*</b>
      </div>
      <b className="absolute top-[10.67%] left-[7.77%] text-lg leading-[26px]">
        MX Gasoline
      </b>
      <div className="absolute top-[53.5px] left-[-0.5px] box-border w-[593px] h-px border-t-[1px] border-solid border-colors-secondary-grey-2" />
      <div className="absolute top-[41.33%] left-[25.17%] text-[inherit] leading-[24px] font-inherit">
        <ul className="m-0 pl-[21px]">
          <li className="mb-0">20.32 cm (8") Infotainment</li>
          <li className="mb-0">17.78 cm (7") Cluster</li>
          <li>Smart Door handles</li>
        </ul>
      </div>
      <b className="absolute top-[41.33%] left-[7.77%] leading-[24px]">
        Key Features
      </b>
      <b className="absolute top-[41.33%] left-[7.77%] leading-[24px]">
        Key Features
      </b>
    </div>
  );
};

export default MXGasolineContainer;
